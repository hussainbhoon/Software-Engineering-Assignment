
/* File: src/components/Footer.js */

import React from 'react';

function Footer() {
  return (
    <footer className="bg-blue-600 text-white p-4 mt-6">
      <div className="container mx-auto text-center">
        <p>© 2023 Ethics Quest. All rights reserved.</p>
      </div>
    </footer>
  );
}

export default Footer;
