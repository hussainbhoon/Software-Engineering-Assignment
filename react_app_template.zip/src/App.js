
/* File: src/App.js */

import React from 'react';
import Header from './components/Header';
import Main from './components/Main';
import Footer from './components/Footer';

function App() {
  return (
    <div className="bg-gray-100 font-roboto">
      <Header />
      <Main />
      <Footer />
    </div>
  );
}

export default App;
