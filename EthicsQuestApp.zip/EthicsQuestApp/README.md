
# Ethics Quest App

This project is a mobile application for ethical education with modules for:
1. Content Creation Engine (Quizzes, Videos, Stories)
2. Gamification (Points, Badges, Leaderboards)

## Frontend
- Built with Flutter.

## Backend
- Firebase integration for real-time data and authentication.

## Setup
1. Install Flutter SDK.
2. Initialize Firebase in your project.
3. Run `flutter pub get` to install dependencies.
4. Use `flutter run` to start the application.

## Deployment
- Configured for hosting on Netlify or Firebase Hosting.
