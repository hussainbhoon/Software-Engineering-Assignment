
import 'package:flutter/material.dart';

void main() {
  runApp(EthicsQuestApp());
}

class EthicsQuestApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ethics Quest'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ContentCreationPage()),
                );
              },
              child: Text('Content Creation Engine'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => GamificationPage()),
                );
              },
              child: Text('Gamification Module'),
            ),
          ],
        ),
      ),
    );
  }
}

class ContentCreationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Content Creation Engine'),
      ),
      body: Center(
        child: Text('AI quizzes, videos, and stories coming soon!'),
      ),
    );
  }
}

class GamificationPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gamification Module'),
      ),
      body: Center(
        child: Text('Points, badges, and leaderboards!'),
      ),
    );
  }
}
